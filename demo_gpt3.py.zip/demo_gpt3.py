import gradio as gr
from transformers import pipeline
import openai
from secc import secc
from random import randint

# generator = pipeline('text-generation', model='gpt2')


def parsear_estado(estado):
    if estado[0] == 'Obra Nueva':
        return 'Es de obra nueva'
    if estado[0] == 'Buen estado':
        return 'Está en buen estado'
    if estado[0] == 'a reformar':
        return 'Necesita reformas'

def parsear_param_con_listas(lista):
    # Esta función sirve para poder coger los parámetros que se introducen por listas y representarlos:
    # extras: ['Aire acondicionado', 'Gimnasio'] -> aire acondicionado, gimnasio
     return ', '.join(lista)



def api_gpt3(arg, metros, anno_const, hab, salones, cocinas, bannos, 
            balcones, terrazas, ascensores, estado, tipo, planta, extras, gastos):
    # De esta lista de keywords se cogerán dos aleatorias en cada llamada
    l_keywords = ['Fantástica','Maravillosa','Fenomenal','Oportunidad','Espaciosa','Amplia'] # 'Apartamento para [familias, parejas]'
    # Aquí recibimos todos los parámetros introducidos por el usuario
    # A continuación preparamos nuestra llamada, la solicitud que le vamos a hacer a ChatGPT3
    llamada = f'''Hazme una descripción para un anuncio de un {tipo[0]} de {metros} metros cuadrados,
    construido en el año {anno_const}, {hab} habitaciones, {salones} salones, {cocinas} cocina, 
    {bannos} baños, {balcones} balcones y {terrazas} terraza. El edificio cuenta con {ascensores} ascensor
    y está en la {planta[0]}. {parsear_estado(estado)}. Tiene {parsear_param_con_listas(extras)}. Los gastos que tiene son {parsear_param_con_listas(gastos)}.
    Complétalo para que la descripción sea muy llamativa y tenga alrededor de 400 carácteres. Usa adjetivos como {l_keywords[randint(0,len(l_keywords)-1)]} y {l_keywords[randint(0,len(l_keywords)-1)]}.'''
    # Quitamos los saltos de línea para que se vea correctamente la llamada
    llamada = llamada.replace('\n   ','')
    print(llamada)
    # Función que llama al modelo
    result = llamada_api_gpt3(llamada)
    return result.replace('\n\n','')



def llamada_api_gpt3(pregunta):
    # Establecemos nuestra clave de API
    openai.api_key = secc['api_key']

    # Consulta que le queremos hacer a Open Ai
    # pregunta: pasada por parámetro
    # Petición a openai
    tokens = 400 # Número de carácteres de la respuesta del bot
    causa_parada = 'length' # Forzamos la primera vez para que pueda entrar en el bucle
    while causa_parada == 'length':
        response = openai.Completion.create(
            model='text-davinci-003', 
            prompt= pregunta,
            max_tokens= tokens, # Tokens: secuencias habituales de caráteres | https://beta.openai.com/tokenizer
            temperature=0.5 # 0: va a lo más seguro, por lo que los resultados no cambian en cada petición | 1: arriesga más
            )
        tokens = tokens*2
        causa_parada = response['choices'][0]['finish_reason']

    respuesta_ia = response['choices'][0]['text']
    return respuesta_ia



def interfaz():
    examples = [
        ["The Moon's orbit around Earth has"],
        ["The smooth Borealis basin in the Northern Hemisphere covers 40%"],
    ]

    demo = gr.Interface(
        fn=api_gpt3, # Función a la que se le pasan por parámetro los inputs
        inputs=[(gr.Textbox(label="Error", visible=False)),
                (gr.Textbox(label="Metros Cuadrados")),
                (gr.Dropdown(["Antes de 1920", "De 1900 a 1920", "De 1921 a 1940",
                            "De 1941 a 1950", "De 1951 a 1960", "De 1961 a 1970",
                            "De 1971 a 1980", "De 1981 a 1990", "De 1991 a 2001",
                            "De 2002 a 2011", "De 2012 a 2021", "No consta"], label="Año de construcción")),
                            (gr.Dropdown(["0 habitaciones(estudios)", "1", "2",
                            "3", "4 habitaciones o más"], label="Habitaciones")),
                            (gr.Dropdown(["1", "2","3 o más"], label="Salones")),
                            (gr.Dropdown(["1", "2","3 o más"], label="Cocinas")),
                            (gr.Dropdown(["1", "2","3 o más"], label="Baños")),
                            (gr.Dropdown(["1", "2","3 o más"], label="Balcones")),
                            (gr.Dropdown(["1", "2","3 o más"], label="Terrazas")),
                            (gr.Dropdown(["1", "2","3 o más"], label="Ascensores")),
                            (gr.CheckboxGroup(["Obra Nueva", "Buen estado", "A reformar"], label="Estado")),
                            (gr.CheckboxGroup(["Pisos", "Áticos", "Dúplex", "Adosados", "Casas Rústicas", "Apartamentos",
                                "Villas", "Lofts"], label="Tipo")),
                            (gr.CheckboxGroup(["Ultima Planta", "Plantas intermedias", "Planta Baja"], label="Planta")),
                            (gr.CheckboxGroup(["Aire Acondicionado", "Climatización", "Calefacción", "Piscina", "Pista de tenis", "Gimnasio",
                                "Garaje"], label="Extras")),
                            (gr.CheckboxGroup(["Gastos de Comunidad", "IBI"], label="Gastos"))],
        outputs=gr.outputs.Textbox(label="Descripción generada"),
            
        # examples=examples
    )

    demo.launch(debug=True)



interfaz()